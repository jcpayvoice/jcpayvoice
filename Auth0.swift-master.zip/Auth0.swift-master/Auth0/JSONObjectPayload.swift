import Foundation

protocol JSONObjectPayload {

    init?(json: [String: Any])

}
